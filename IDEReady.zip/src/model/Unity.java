package model;

public class Unity extends SaleType {

	public Unity() {
		super(3, "Unidade", "U");
	}

}