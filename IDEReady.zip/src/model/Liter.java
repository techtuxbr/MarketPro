package model;

public class Liter extends SaleType {

	public Liter() {
		super(2, "Litro", "L");
	}

}
