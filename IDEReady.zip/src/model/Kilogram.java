package model;

public class Kilogram extends SaleType {

	public Kilogram() {
		super(1, "Quilograma", "KG");
	}

}