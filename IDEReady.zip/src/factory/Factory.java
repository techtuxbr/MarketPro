package factory;

public abstract class Factory {

	public Factory() {
		// TODO Auto-generated constructor stub
	}

}
